import {makeAutoObservable, runInAction} from 'mobx';
import {makePersistable} from 'mobx-persist-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {v4 as uuidv4} from 'uuid';

import {chunkText, retrieveContext} from '../services/knowledgeBase/retrieval';

export interface KnowledgeFile {
  id: string;
  name: string;
  extension: string;
  sizeBytes: number;
  /** Extracted text (truncated to a safe cap for persistence). */
  text: string;
  /** Precomputed retrieval chunks derived from `text`. */
  chunks: string[];
  enabled: boolean;
  addedAt: number;
}

export interface KnowledgeBase {
  id: string;
  name: string;
  enabled: boolean;
  createdAt: number;
  files: KnowledgeFile[];
}

export type ChatFileMode = 'all' | 'selected' | 'none';

/** Cap on indexed text per file to keep the persisted store small. */
const MAX_FILE_TEXT_CHARS = 200000;

export interface AddFileInput {
  name: string;
  text: string;
  extension: string;
  sizeBytes: number;
}

export class KnowledgeBaseStore {
  knowledgeBases: KnowledgeBase[] = [];
  /** Master switch for the whole knowledge-base feature. */
  masterEnabled = true;
  /** Per-current-chat toggle (user can temporarily disable KB for a chat). */
  chatKbEnabled = true;
  /** Which files feed the current chat: all enabled, an explicit selection, or none. */
  chatFileMode: ChatFileMode = 'all';
  chatSelectedFileIds: string[] = [];

  constructor() {
    makeAutoObservable(this, {}, {autoBind: true});
    makePersistable(this, {
      name: 'KnowledgeBaseStore',
      properties: [
        'knowledgeBases',
        'masterEnabled',
        'chatKbEnabled',
        'chatFileMode',
        'chatSelectedFileIds',
      ],
      storage: AsyncStorage,
    });
  }

  // ---- Knowledge base CRUD ------------------------------------------------

  createKnowledgeBase(name: string): KnowledgeBase {
    const kb: KnowledgeBase = {
      id: uuidv4(),
      name: name.trim() || `知识库 ${this.knowledgeBases.length + 1}`,
      enabled: true,
      createdAt: Date.now(),
      files: [],
    };
    runInAction(() => {
      this.knowledgeBases.push(kb);
    });
    return kb;
  }

  removeKnowledgeBase(kbId: string) {
    runInAction(() => {
      this.knowledgeBases = this.knowledgeBases.filter(k => k.id !== kbId);
      const remaining = new Set(
        this.knowledgeBases.flatMap(k => k.files.map(f => f.id)),
      );
      this.chatSelectedFileIds = this.chatSelectedFileIds.filter(id =>
        remaining.has(id),
      );
    });
  }

  renameKnowledgeBase(kbId: string, name: string) {
    runInAction(() => {
      const kb = this.knowledgeBases.find(k => k.id === kbId);
      if (kb && name.trim()) {
        kb.name = name.trim();
      }
    });
  }

  setKbEnabled(kbId: string, enabled: boolean) {
    runInAction(() => {
      const kb = this.knowledgeBases.find(k => k.id === kbId);
      if (kb) {
        kb.enabled = enabled;
      }
    });
  }

  // ---- File CRUD ----------------------------------------------------------

  addFile(kbId: string, input: AddFileInput): KnowledgeFile | null {
    const kb = this.knowledgeBases.find(k => k.id === kbId);
    if (!kb) {
      return null;
    }
    const text = (input.text || '').slice(0, MAX_FILE_TEXT_CHARS);
    const file: KnowledgeFile = {
      id: uuidv4(),
      name: input.name,
      extension: input.extension,
      sizeBytes: input.sizeBytes,
      text,
      chunks: chunkText(text),
      enabled: true,
      addedAt: Date.now(),
    };
    runInAction(() => {
      kb.files.push(file);
    });
    return file;
  }

  removeFile(kbId: string, fileId: string) {
    runInAction(() => {
      const kb = this.knowledgeBases.find(k => k.id === kbId);
      if (kb) {
        kb.files = kb.files.filter(f => f.id !== fileId);
      }
      this.chatSelectedFileIds = this.chatSelectedFileIds.filter(
        id => id !== fileId,
      );
    });
  }

  replaceFile(kbId: string, fileId: string, input: AddFileInput) {
    runInAction(() => {
      const kb = this.knowledgeBases.find(k => k.id === kbId);
      if (!kb) {
        return;
      }
      const text = (input.text || '').slice(0, MAX_FILE_TEXT_CHARS);
      const file = kb.files.find(f => f.id === fileId);
      if (file) {
        file.name = input.name;
        file.extension = input.extension;
        file.sizeBytes = input.sizeBytes;
        file.text = text;
        file.chunks = chunkText(text);
        file.addedAt = Date.now();
      }
    });
  }

  setFileEnabled(kbId: string, fileId: string, enabled: boolean) {
    runInAction(() => {
      const kb = this.knowledgeBases.find(k => k.id === kbId);
      const file = kb?.files.find(f => f.id === fileId);
      if (file) {
        file.enabled = enabled;
      }
    });
  }

  // ---- Master / chat-level controls --------------------------------------

  toggleMaster() {
    runInAction(() => {
      this.masterEnabled = !this.masterEnabled;
    });
  }

  setMasterEnabled(value: boolean) {
    runInAction(() => {
      this.masterEnabled = value;
    });
  }

  setChatKbEnabled(value: boolean) {
    runInAction(() => {
      this.chatKbEnabled = value;
    });
  }

  setChatFileMode(mode: ChatFileMode) {
    runInAction(() => {
      this.chatFileMode = mode;
    });
  }

  toggleChatFile(fileId: string) {
    runInAction(() => {
      this.chatFileMode = 'selected';
      if (this.chatSelectedFileIds.includes(fileId)) {
        this.chatSelectedFileIds = this.chatSelectedFileIds.filter(
          id => id !== fileId,
        );
      } else {
        this.chatSelectedFileIds.push(fileId);
      }
    });
  }

  selectAllChatFiles() {
    runInAction(() => {
      this.chatFileMode = 'all';
      this.chatSelectedFileIds = [];
    });
  }

  clearChatFiles() {
    runInAction(() => {
      this.chatFileMode = 'none';
      this.chatSelectedFileIds = [];
    });
  }

  invertChatFiles() {
    runInAction(() => {
      const all = this.getEnabledCandidateFiles().map(f => f.id);
      const selected = new Set(this.chatSelectedFileIds);
      this.chatSelectedFileIds = all.filter(id => !selected.has(id));
      this.chatFileMode = 'selected';
    });
  }

  // ---- Selection helpers --------------------------------------------------

  getEnabledCandidateFiles(): KnowledgeFile[] {
    const result: KnowledgeFile[] = [];
    for (const kb of this.knowledgeBases) {
      if (!kb.enabled) {
        continue;
      }
      for (const f of kb.files) {
        if (f.enabled) {
          result.push(f);
        }
      }
    }
    return result;
  }

  /** Files that will actually be used for the current chat. */
  getActiveChatFiles(): KnowledgeFile[] {
    if (!this.masterEnabled || !this.chatKbEnabled) {
      return [];
    }
    const candidates = this.getEnabledCandidateFiles();
    if (this.chatFileMode === 'none') {
      return [];
    }
    if (this.chatFileMode === 'all') {
      return candidates;
    }
    const selected = new Set(this.chatSelectedFileIds);
    return candidates.filter(f => selected.has(f.id));
  }

  /** Assemble retrieval context for a user query. Empty string when disabled. */
  buildContext(
    query: string,
    opts?: {maxChunks?: number; maxChars?: number},
  ): string {
    const files = this.getActiveChatFiles();
    if (files.length === 0) {
      return '';
    }
    const ctx = retrieveContext(query, files, opts);
    if (!ctx.trim()) {
      return '';
    }
    // Frame the retrieval result as reference material so small models
    // (e.g. qwen) don't treat it as text to copy/continue, which previously
    // caused repetitive loops. The model must answer in its own words and never
    // echo the reference verbatim.
    return (
      'Below is reference material from the local knowledge base. ' +
      'Use it ONLY to help answer the user. Do NOT copy, translate, or ' +
      'paraphrase it as your reply, and do NOT repeat it back. ' +
      'Answer concisely in the user’s language.\n\n' +
      ctx
    );
  }

  get activeFileCount(): number {
    return this.getActiveChatFiles().length;
  }
}

export const knowledgeBaseStore = new KnowledgeBaseStore();
