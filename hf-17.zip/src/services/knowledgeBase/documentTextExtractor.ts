// Extract plain text from an uploaded document so it can be indexed into a
// knowledge base and/or sent to the model for analysis.
//
// Support matrix:
//   - Text-like files (txt/md/code/sh/bat/py/json/csv/log/xml/yml/... and files
//     without an extension) are read directly as UTF-8.
//   - PDF: best-effort extraction of literal text objects (works for many
//     uncompressed / lightly compressed PDFs; FlateDecode streams may yield
//     little text).
//   - Office Open XML (docx/doc, xlsx/xls, pptx/ppt): parsed via jszip.
//
// Anything we cannot parse still gets stored as a file; it just won't contribute
// retrievable text until a parser supports it.

import RNFS from '@dr.pogodin/react-native-fs';
import JSZip from 'jszip';

const TEXT_EXTENSIONS = new Set([
  'txt', 'text', 'md', 'markdown', 'mdx',
  'sh', 'bash', 'bat', 'cmd', 'ps1',
  'py', 'js', 'jsx', 'ts', 'tsx', 'mjs', 'cjs',
  'json', 'csv', 'tsv', 'log', 'xml', 'yml', 'yaml',
  'cfg', 'ini', 'conf', 'toml', 'env',
  'cpp', 'c', 'h', 'hpp', 'cc', 'java', 'kt', 'go', 'rs',
  'php', 'rb', 'sql', 'html', 'htm', 'css', 'scss', 'less', 'swift',
]);

const OFFICE_EXTENSIONS = new Set([
  'docx', 'doc', 'xlsx', 'xls', 'pptx', 'ppt',
]);

export interface ExtractResult {
  text: string;
  extension: string;
}

function getExtension(fileName: string): string {
  const lower = (fileName || '').toLowerCase();
  const dot = lower.lastIndexOf('.');
  return dot >= 0 ? lower.slice(dot + 1) : 'noext';
}

export async function extractTextFromFile(
  uri: string,
  fileName: string,
  _mimeType?: string,
): Promise<ExtractResult> {
  const extension = getExtension(fileName);

  try {
    if (TEXT_EXTENSIONS.has(extension) || extension === 'noext') {
      const text = await RNFS.readFile(uri, 'utf8');
      return {text: text || '', extension};
    }

    if (extension === 'pdf') {
      const base64 = await RNFS.readFile(uri, 'base64');
      return {text: extractPdfText(base64), extension};
    }

    if (OFFICE_EXTENSIONS.has(extension)) {
      const base64 = await RNFS.readFile(uri, 'base64');
      const text = await extractOfficeText(base64, extension);
      return {text, extension};
    }

    // Unknown extension: best-effort UTF-8 read.
    const text = await RNFS.readFile(uri, 'utf8');
    return {text: text || '', extension};
  } catch {
    // Last resort: ignore parse errors and return whatever we can.
    try {
      const text = await RNFS.readFile(uri, 'utf8');
      return {text: text || '', extension};
    } catch {
      return {text: '', extension};
    }
  }
}

// ----- PDF (best-effort) ---------------------------------------------------

function extractPdfText(base64: string): string {
  try {
    const binary = atob(base64);
    const out: string[] = [];
    const re = /\(((?:[^()\\]|\\.)*)\)/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(binary)) !== null) {
      const raw = m[1];
      if (!raw.trim()) {
        continue;
      }
      const decoded = raw.replace(
        /\\([nrtbf()\\])/g,
        (_match, c: string) =>
          ({n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '(': '(', ')': ')', '\\': '\\'}[c] ||
            c),
      );
      if (decoded.trim()) {
        out.push(decoded);
      }
    }
    return out.join('\n');
  } catch {
    return '';
  }
}

// ----- Office Open XML (jszip) --------------------------------------------

async function extractOfficeText(
  base64: string,
  extension: string,
): Promise<string> {
  try {
    const zip = await JSZip.loadAsync(base64, {base64: true});

    if (extension === 'docx' || extension === 'doc') {
      const xml = await zip.file('word/document.xml')?.async('string');
      return xml ? extractXmlText(xml, /<w:t[^>]*>([^<]*)<\/w:t>/g) : '';
    }

    if (extension === 'pptx' || extension === 'ppt') {
      const slideNames = Object.keys(zip.files).filter(name =>
        /ppt\/slides\/slide\d+\.xml$/.test(name),
      );
      const parts: string[] = [];
      for (const name of slideNames) {
        const xml = await zip.file(name)?.async('string');
        if (xml) {
          parts.push(extractXmlText(xml, /<a:t>([^<]*)<\/a:t>/g));
        }
      }
      return parts.join('\n');
    }

    if (extension === 'xlsx' || extension === 'xls') {
      const parts: string[] = [];
      const shared = await zip.file('xl/sharedStrings.xml')?.async('string');
      if (shared) {
        parts.push(extractXmlText(shared, /<t[^>]*>([^<]*)<\/t>/g));
      }
      const sheetNames = Object.keys(zip.files).filter(name =>
        /xl\/worksheets\/sheet\d+\.xml$/.test(name),
      );
      for (const name of sheetNames) {
        const xml = await zip.file(name)?.async('string');
        if (xml) {
          parts.push(extractXmlText(xml, /<t[^>]*>([^<]*)<\/t>/g));
        }
      }
      return parts.join('\n');
    }
  } catch {
    return '';
  }
  return '';
}

function extractXmlText(xml: string, re: RegExp): string {
  const parts: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(xml)) !== null) {
    if (m[1]) {
      parts.push(m[1]);
    }
  }
  return parts.join(' ');
}
