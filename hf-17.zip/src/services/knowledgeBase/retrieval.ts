// Local, dependency-free retrieval for the knowledge base.
//
// Documents are split into overlapping chunks at index time. At query time we
// score each chunk by lexical overlap with the query (a lightweight BM25-ish
// signal) and return the top chunks concatenated as context. No external model
// or embedding is required, so everything runs fully offline on device.

const CHUNK_SIZE = 600;
const CHUNK_OVERLAP = 80;

/**
 * Split text into retrieval chunks. Paragraphs are used as natural boundaries;
 * long paragraphs are hard-split. Chunks overlap slightly so a match near a
 * boundary is not split awkwardly.
 */
export function chunkText(text: string): string[] {
  if (!text || !text.trim()) {
    return [];
  }

  const normalized = text.replace(/\r\n/g, '\n');
  const paragraphs = normalized
    .split(/\n{1,}/)
    .map(p => p.trim())
    .filter(Boolean);

  const chunks: string[] = [];
  let buffer = '';

  const flush = () => {
    const trimmed = buffer.trim();
    if (trimmed) {
      chunks.push(trimmed);
    }
    // keep a tail for overlap
    buffer = buffer.slice(Math.max(0, buffer.length - CHUNK_OVERLAP));
  };

  for (const para of paragraphs) {
    if (buffer && (buffer.length + para.length + 1) > CHUNK_SIZE) {
      flush();
    }
    buffer = buffer ? `${buffer}\n${para}` : para;
  }
  if (buffer.trim()) {
    chunks.push(buffer.trim());
  }

  // Single wall-of-text fallback (no paragraph breaks).
  if (chunks.length === 0 && normalized.trim()) {
    const t = normalized.trim();
    for (let i = 0; i < t.length; i += CHUNK_SIZE - CHUNK_OVERLAP) {
      const slice = t.slice(i, i + CHUNK_SIZE).trim();
      if (slice) {
        chunks.push(slice);
      }
    }
  }

  return chunks;
}

// Tokenize into latin/alnum runs and CJK characters. Good enough for lexical
// overlap scoring across both English and Chinese queries.
const TOKEN_RE = /[a-z0-9]+|[一-鿿]/gi;

export function tokenize(s: string): string[] {
  return (s.toLowerCase().match(TOKEN_RE) || []) as string[];
}

/**
 * Score a single chunk against a query. Combines token-overlap frequency with a
 * length-normalization term and a phrase-substring boost.
 */
export function scoreChunk(query: string, chunk: string): number {
  const queryTokens = tokenize(query);
  if (queryTokens.length === 0) {
    return 0;
  }

  const chunkTokens = tokenize(chunk);
  const freq = new Map<string, number>();
  for (const t of chunkTokens) {
    freq.set(t, (freq.get(t) || 0) + 1);
  }

  const chunkLen = chunkTokens.length || 1;
  const querySet = new Set(queryTokens);
  let score = 0;
  for (const t of querySet) {
    const c = freq.get(t) || 0;
    if (c > 0) {
      // term frequency weighted by a mild length normalization
      score += c * (1 / (1 + Math.log10(1 + chunkLen / 20)));
    }
  }

  const phrase = query.trim().toLowerCase();
  if (phrase && chunk.toLowerCase().includes(phrase)) {
    score += 2;
  }

  return score;
}

export interface RetrievalFile {
  name: string;
  chunks: string[];
}

export interface RetrieveOptions {
  maxChunks?: number;
  maxChars?: number;
  minScore?: number;
}

/**
 * Assemble retrieval context for a query from a set of files. Returns an empty
 * string when nothing scores above the threshold (caller then injects nothing).
 */
export function retrieveContext(
  query: string,
  files: RetrievalFile[],
  opts?: RetrieveOptions,
): string {
  const maxChunks = opts?.maxChunks ?? 6;
  const maxChars = opts?.maxChars ?? 4000;
  const minScore = opts?.minScore ?? 0.5;

  const scored: Array<{text: string; file: string; score: number}> = [];

  for (const file of files) {
    for (const chunk of file.chunks) {
      const s = scoreChunk(query, chunk);
      if (s > minScore) {
        scored.push({text: chunk, file: file.name, score: s});
      }
    }
  }

  if (scored.length === 0) {
    return '';
  }

  scored.sort((a, b) => b.score - a.score);
  const picked = scored.slice(0, maxChunks);

  let out = '';
  let used = 0;
  for (const p of picked) {
    if (used + p.text.length > maxChars) {
      break;
    }
    out += `\n[来源: ${p.file}]\n${p.text}\n`;
    used += p.text.length;
  }

  return out.trim();
}
