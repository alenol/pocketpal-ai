import React, {useState} from 'react';
import {observer} from 'mobx-react';
import {
  ActivityIndicator,
  Appbar,
  Button,
  Dialog,
  Divider,
  Portal,
  Switch,
  Text,
  TextInput,
} from 'react-native-paper';
import {Alert, TouchableOpacity, View} from 'react-native';
import {pick, types} from '@react-native-documents/picker';

import {useTheme} from '../../hooks';
import {L10nContext} from '../../utils';
import {formatBytes} from '../../utils';
import {kbL10n} from '../../utils/knowledgeBaseL10n';
import {knowledgeBaseStore} from '../../store';
import {ROUTES} from '../../utils/navigationConstants';
import {extractTextFromFile} from '../../services/knowledgeBase/documentTextExtractor';
import {createStyles} from './styles';

const ANALYZE_TEXT_CAP = 12000;

const getT = (l10nCtx: any) => kbL10n(l10nCtx);

interface Props {
  kbId: string;
  onBack: () => void;
  navigation: any;
}

export const KnowledgeBaseDetailScreen = observer(({kbId, onBack, navigation}: Props) => {
  const theme = useTheme();
  const styles = createStyles(theme);
  const l10nCtx = React.useContext(L10nContext);
  const t = getT(l10nCtx);

  const [busy, setBusy] = useState(false);
  const [renameVisible, setRenameVisible] = useState(false);
  const [renameValue, setRenameValue] = useState('');
  const [deleteKbVisible, setDeleteKbVisible] = useState(false);
  const [deleteFileId, setDeleteFileId] = useState<string | null>(null);

  const kb = knowledgeBaseStore.knowledgeBases.find(k => k.id === kbId);

  if (!kb) {
    return (
      <View style={styles.container}>
        <Appbar.Header>
          <Appbar.BackAction onPress={onBack} />
          <Appbar.Content title={t.title} />
        </Appbar.Header>
        <View style={styles.center}>
          <Text style={styles.emptyText}>{t.kbNotFound}</Text>
        </View>
      </View>
    );
  }

  const openPicker = async (replaceFileId?: string) => {
    try {
      const results = await pick({
        type: [types.allFiles],
        allowMultiSelection: !replaceFileId,
      });
      if (!results || results.length === 0) {
        return;
      }
      setBusy(true);
      try {
        for (const doc of results) {
          const {text, extension} = await extractTextFromFile(
            doc.uri,
            doc.name,
            (doc as any).type,
          );
          const size = (doc as any).size || text.length;
          if (replaceFileId) {
            knowledgeBaseStore.replaceFile(kbId, replaceFileId, {
              name: doc.name,
              text,
              extension,
              sizeBytes: size,
            });
          } else {
            knowledgeBaseStore.addFile(kbId, {
              name: doc.name,
              text,
              extension,
              sizeBytes: size,
            });
          }
        }
      } catch (e) {
        Alert.alert(t.extractErrorTitle, t.extractErrorBody);
      } finally {
        setBusy(false);
      }
    } catch (e: any) {
      // user cancelled the picker
      if (e?.code !== 'CANCELLED') {
        // ignore cancellation, surface others
      }
    }
  };

  const analyze = (fileId: string) => {
    const file = kb!.files.find(f => f.id === fileId);
    if (!file) {
      return;
    }
    const text = file.text.slice(0, ANALYZE_TEXT_CAP);
    navigation.navigate(ROUTES.CHAT, {
      analysisDoc: {
        name: file.name,
        text,
      },
    });
  };

  const confirmDeleteKb = () => {
    knowledgeBaseStore.removeKnowledgeBase(kbId);
    setDeleteKbVisible(false);
    onBack();
  };

  const confirmDeleteFile = () => {
    if (deleteFileId) {
      knowledgeBaseStore.removeFile(kbId, deleteFileId);
    }
    setDeleteFileId(null);
  };

  return (
    <View style={styles.container}>
      <Appbar.Header>
        <Appbar.BackAction onPress={onBack} />
        <Appbar.Content title={kb.name} />
        <Appbar.Action
          icon="plus"
          onPress={() => openPicker()}
          accessibilityLabel={t.addDocuments}
        />
        <Appbar.Action
          icon="pencil"
          onPress={() => {
            setRenameValue(kb.name);
            setRenameVisible(true);
          }}
        />
        <Appbar.Action
          icon="delete"
          onPress={() => setDeleteKbVisible(true)}
        />
        <Switch
          value={kb.enabled}
          onValueChange={v => knowledgeBaseStore.setKbEnabled(kbId, v)}
        />
      </Appbar.Header>

      <View style={styles.content}>
        {busy && (
          <View style={{marginBottom: 12, alignItems: 'center'}}>
            <ActivityIndicator />
            <Text style={styles.cardMeta}>{t.processing}</Text>
          </View>
        )}

        <Text style={styles.sectionTitle}>
          {t.files} ({kb.files.length})
        </Text>

        {kb.files.length === 0 && (
          <View style={styles.center}>
            <Text style={styles.emptyText}>{t.noFiles}</Text>
            <Button mode="contained" onPress={() => openPicker()} style={{marginTop: 12}}>
              {t.addDocuments}
            </Button>
          </View>
        )}

        {kb.files.map(file => (
          <View key={file.id} style={styles.fileRow}>
            <View style={styles.fileInfo}>
              <Text style={styles.fileName} numberOfLines={2}>
                {file.name}
              </Text>
              <Text style={styles.fileMeta}>
                {formatBytes(file.sizeBytes)} · {file.chunks.length} {t.chunks}
                {file.enabled ? '' : ` · ${t.disabled}`}
              </Text>
            </View>
            <View style={styles.fileActions}>
              <TouchableOpacity
                onPress={() => analyze(file.id)}
                accessibilityLabel={t.analyze}>
                <Text style={{color: theme.colors.primary, marginHorizontal: 8}}>
                  {t.analyze}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => openPicker(file.id)}
                accessibilityLabel={t.replace}>
                <Text style={{color: theme.colors.primary, marginHorizontal: 8}}>
                  {t.replace}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => setDeleteFileId(file.id)}
                accessibilityLabel={t.delete}>
                <Text style={{color: theme.colors.error, marginHorizontal: 8}}>
                  {t.delete}
                </Text>
              </TouchableOpacity>
              <Switch
                value={file.enabled}
                onValueChange={v =>
                  knowledgeBaseStore.setFileEnabled(kbId, file.id, v)
                }
              />
            </View>
          </View>
        ))}
      </View>

      {/* Rename dialog */}
      <Portal>
        <Dialog visible={renameVisible} onDismiss={() => setRenameVisible(false)}>
          <Dialog.Title>{t.renameKb}</Dialog.Title>
          <Dialog.Content>
            <TextInput
              value={renameValue}
              onChangeText={setRenameValue}
              mode="outlined"
              style={styles.input}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setRenameVisible(false)}>{t.cancel}</Button>
            <Button
              onPress={() => {
                knowledgeBaseStore.renameKnowledgeBase(kbId, renameValue);
                setRenameVisible(false);
              }}>
              {t.save}
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Delete KB dialog */}
      <Portal>
        <Dialog visible={deleteKbVisible} onDismiss={() => setDeleteKbVisible(false)}>
          <Dialog.Title>{t.deleteKb}</Dialog.Title>
          <Dialog.Content>
            <Text style={styles.dialogText}>{t.deleteKbConfirm}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteKbVisible(false)}>{t.cancel}</Button>
            <Button onPress={confirmDeleteKb}>{t.delete}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Delete file dialog */}
      <Portal>
        <Dialog
          visible={deleteFileId !== null}
          onDismiss={() => setDeleteFileId(null)}>
          <Dialog.Title>{t.deleteFile}</Dialog.Title>
          <Dialog.Content>
            <Text style={styles.dialogText}>{t.deleteFileConfirm}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteFileId(null)}>{t.cancel}</Button>
            <Button onPress={confirmDeleteFile}>{t.delete}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
});
