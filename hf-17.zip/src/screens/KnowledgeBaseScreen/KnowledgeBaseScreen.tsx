import React, {useState} from 'react';
import {observer} from 'mobx-react';
import {
  Appbar,
  Button,
  Dialog,
  Divider,
  FAB,
  Portal,
  Switch,
  Text,
  TextInput,
} from 'react-native-paper';
import {View} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';

import {useTheme} from '../../hooks';
import {L10nContext} from '../../utils';
import {kbL10n} from '../../utils/knowledgeBaseL10n';
import {knowledgeBaseStore} from '../../store';
import {createStyles} from './styles';
import {KnowledgeBaseDetailScreen} from './KnowledgeBaseDetailScreen';



export const KnowledgeBaseScreen = observer(({navigation}: any) => {
  const theme = useTheme();
  const styles = createStyles(theme);
  const l10nCtx = React.useContext(L10nContext);
  const t = kbL10n(l10nCtx);

  const [selectedKbId, setSelectedKbId] = useState<string | null>(null);
  const [createVisible, setCreateVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [renameId, setRenameId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');

  if (selectedKbId) {
    return (
      <KnowledgeBaseDetailScreen
        kbId={selectedKbId}
        onBack={() => setSelectedKbId(null)}
        navigation={navigation}
      />
    );
  }

  const createKb = () => {
    knowledgeBaseStore.createKnowledgeBase(newName);
    setNewName('');
    setCreateVisible(false);
  };

  const totalFiles = knowledgeBaseStore.knowledgeBases.reduce(
    (acc, kb) => acc + kb.files.length,
    0,
  );

  return (
    <View style={styles.container}>
      <Appbar.Header>
        <Appbar.Content title={t.title} />
        <Appbar.Action icon="plus" onPress={() => setCreateVisible(true)} />
      </Appbar.Header>

      <View style={styles.content}>
        {/* Master switch */}
        <View style={styles.masterRow}>
          <View>
            <Text style={styles.masterTitle}>{t.masterTitle}</Text>
            <Text style={styles.masterHint}>{t.masterHint}</Text>
          </View>
          <Switch
            value={knowledgeBaseStore.masterEnabled}
            onValueChange={v => knowledgeBaseStore.setMasterEnabled(v)}
          />
        </View>

        <Divider />

        {/* List */}
        {knowledgeBaseStore.knowledgeBases.length === 0 ? (
          <View style={styles.center}>
            <Text style={styles.emptyText}>{t.empty}</Text>
            <Button
              mode="contained"
              onPress={() => setCreateVisible(true)}
              style={{marginTop: 12}}>
              {t.create}
            </Button>
          </View>
        ) : (
          knowledgeBaseStore.knowledgeBases.map(kb => (
            <TouchableOpacity
              key={kb.id}
              onPress={() => setSelectedKbId(kb.id)}
              accessibilityLabel={kb.name}>
              <View style={styles.card}>
                <View style={styles.cardRow}>
                  <Text style={styles.cardTitle} numberOfLines={1}>
                    {kb.name}
                  </Text>
                  <Switch
                    value={kb.enabled}
                    onValueChange={v =>
                      knowledgeBaseStore.setKbEnabled(kb.id, v)
                    }
                  />
                </View>
                <Text style={styles.cardMeta}>
                  {kb.files.length} {t.files}
                  {!kb.enabled ? ` · ${t.disabled}` : ''}
                </Text>
                <View style={styles.actions}>
                  <Button
                    compact
                    mode="text"
                    onPress={() => {
                      setRenameId(kb.id);
                      setRenameValue(kb.name);
                    }}>
                    {t.rename}
                  </Button>
                  <Button
                    compact
                    mode="text"
                    textColor={theme.colors.error}
                    onPress={() => setDeleteId(kb.id)}>
                    {t.delete}
                  </Button>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </View>

      <FAB
        icon="plus"
        style={{
          position: 'absolute',
          right: 16,
          bottom: 16,
          backgroundColor: theme.colors.primaryContainer,
        }}
        onPress={() => setCreateVisible(true)}
      />

      {/* Create dialog */}
      <Portal>
        <Dialog visible={createVisible} onDismiss={() => setCreateVisible(false)}>
          <Dialog.Title>{t.createKb}</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label={t.kbNameLabel}
              value={newName}
              onChangeText={setNewName}
              mode="outlined"
              style={styles.input}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setCreateVisible(false)}>{t.cancel}</Button>
            <Button onPress={createKb}>{t.create}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Rename dialog */}
      <Portal>
        <Dialog visible={renameId !== null} onDismiss={() => setRenameId(null)}>
          <Dialog.Title>{t.renameKb}</Dialog.Title>
          <Dialog.Content>
            <TextInput
              value={renameValue}
              onChangeText={setRenameValue}
              mode="outlined"
              style={styles.input}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setRenameId(null)}>{t.cancel}</Button>
            <Button
              onPress={() => {
                if (renameId) {
                  knowledgeBaseStore.renameKnowledgeBase(renameId, renameValue);
                }
                setRenameId(null);
              }}>
              {t.save}
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      {/* Delete dialog */}
      <Portal>
        <Dialog visible={deleteId !== null} onDismiss={() => setDeleteId(null)}>
          <Dialog.Title>{t.deleteKb}</Dialog.Title>
          <Dialog.Content>
            <Text style={styles.dialogText}>{t.deleteKbConfirm}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setDeleteId(null)}>{t.cancel}</Button>
            <Button
              onPress={() => {
                if (deleteId) {
                  knowledgeBaseStore.removeKnowledgeBase(deleteId);
                }
                setDeleteId(null);
              }}>
              {t.delete}
            </Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
});
