// Robust i18n accessor for the Knowledge Base feature.
//
// We keep a full English default inside the app so the UI never crashes even if
// a locale file hasn't been updated with the `knowledgeBase` section yet. The
// current-language strings (and the English overrides) are merged on top when
// present, so translations still apply once locales are updated.

import {l10n} from '../locales';

export const DEFAULT_KB_L10N = {
  title: 'Knowledge Base',
  masterTitle: 'Knowledge Base',
  masterHint: 'When off, documents are not used in any chat.',
  empty: 'No knowledge base yet. Create one to store and search your documents.',
  create: 'Create',
  createKb: 'New Knowledge Base',
  kbNameLabel: 'Knowledge base name',
  rename: 'Rename',
  renameKb: 'Rename Knowledge Base',
  delete: 'Delete',
  deleteKb: 'Delete Knowledge Base',
  deleteKbConfirm:
    'Delete this knowledge base and all its documents? This cannot be undone.',
  disabled: 'Disabled',
  files: 'documents',
  filesUsing: 'files in use',
  noFiles:
    'No documents yet. Add text files (txt, md, pdf, code, office docs) to start.',
  addDocuments: 'Add Documents',
  processing: 'Extracting text…',
  extractErrorTitle: 'Could not read file',
  extractErrorBody: 'The file could not be read or parsed. It was not added.',
  chunks: 'chunks',
  kbNotFound: 'Knowledge base not found.',
  analyze: 'Analyze',
  replace: 'Replace',
  deleteFile: 'Delete Document',
  deleteFileConfirm: 'Remove this document from the knowledge base?',
  kbShort: 'KB',
  selectFiles: 'Select',
  selectFilesTitle: 'Documents used in this chat',
  noEnabledFiles:
    'No enabled documents available. Enable a knowledge base and its documents first.',
  all: 'All',
  invert: 'Invert',
  none: 'None',
  done: 'Done',
  off: 'Off',
  save: 'Save',
  cancel: 'Cancel',
};

export const kbL10n = (l10nCtx: any): typeof DEFAULT_KB_L10N => ({
  ...DEFAULT_KB_L10N,
  ...((l10n as any).en?.knowledgeBase),
  ...(l10nCtx?.knowledgeBase),
});
