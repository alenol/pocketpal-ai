import React, {useState} from 'react';
import {observer} from 'mobx-react';
import {StyleSheet, View} from 'react-native';
import {
  Button,
  Checkbox,
  Modal,
  Portal,
  Switch,
  Text,
} from 'react-native-paper';
import {TouchableOpacity} from 'react-native-gesture-handler';

import {useTheme} from '../hooks';
import {L10nContext} from '../utils';
import {kbL10n} from '../utils/knowledgeBaseL10n';
import {knowledgeBaseStore} from '../store';

const getT = (l10nCtx: any) => kbL10n(l10nCtx);

export const KBControl = observer(() => {
  const theme = useTheme();
  const l10nCtx = React.useContext(L10nContext);
  const t = getT(l10nCtx);
  const [sheetOpen, setSheetOpen] = useState(false);

  // Hidden entirely when the feature is globally disabled.
  if (!knowledgeBaseStore.masterEnabled) {
    return null;
  }

  const candidateFiles = knowledgeBaseStore.getEnabledCandidateFiles();
  const activeCount = knowledgeBaseStore.activeFileCount;

  const styles = StyleSheet.create({
    bar: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 12,
      paddingVertical: 6,
      backgroundColor: theme.colors.surfaceVariant,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.colors.outlineVariant,
    },
    left: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    label: {
      color: theme.colors.onSurface,
      fontWeight: '600',
      marginRight: 8,
    },
    count: {
      color: theme.colors.onSurfaceVariant,
      fontSize: 12,
    },
    selectBtn: {
      marginLeft: 8,
    },
    sheet: {
      backgroundColor: theme.colors.surface,
      margin: 20,
      borderRadius: 12,
      padding: 16,
      maxHeight: '80%',
    },
    sheetTitle: {
      fontSize: 16,
      fontWeight: '700',
      color: theme.colors.onSurface,
      marginBottom: 8,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 8,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.colors.outlineVariant,
    },
    rowText: {
      flex: 1,
      color: theme.colors.onSurface,
      marginLeft: 8,
    },
    toolbar: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 12,
    },
    empty: {
      color: theme.colors.onSurfaceVariant,
      textAlign: 'center',
      paddingVertical: 16,
    },
  });

  return (
    <>
      <View style={styles.bar}>
        <View style={styles.left}>
          <Text style={styles.label}>{t.kbShort}</Text>
          <Text style={styles.count}>
            {knowledgeBaseStore.chatKbEnabled
              ? `${activeCount} ${t.filesUsing}`
              : t.off}
          </Text>
        </View>
        <View style={styles.left}>
          <TouchableOpacity
            onPress={() => setSheetOpen(true)}
            accessibilityLabel={t.selectFiles}>
            <Text style={[styles.label, {color: theme.colors.primary}]}>
              {t.selectFiles}
            </Text>
          </TouchableOpacity>
          <Switch
            value={knowledgeBaseStore.chatKbEnabled}
            onValueChange={v => knowledgeBaseStore.setChatKbEnabled(v)}
          />
        </View>
      </View>

      <Portal>
        <Modal
          visible={sheetOpen}
          onDismiss={() => setSheetOpen(false)}
          contentContainerStyle={styles.sheet}>
          <Text style={styles.sheetTitle}>{t.selectFilesTitle}</Text>

          {candidateFiles.length === 0 ? (
            <Text style={styles.empty}>{t.noEnabledFiles}</Text>
          ) : (
            <>
              {candidateFiles.map(file => {
                const checked = knowledgeBaseStore.chatFileMode === 'all'
                  ? true
                  : knowledgeBaseStore.chatFileMode === 'none'
                  ? false
                  : knowledgeBaseStore.chatSelectedFileIds.includes(file.id);
                return (
                  <TouchableOpacity
                    key={file.id}
                    style={styles.row}
                    onPress={() => knowledgeBaseStore.toggleChatFile(file.id)}>
                    <Checkbox status={checked ? 'checked' : 'unchecked'} />
                    <Text style={styles.rowText} numberOfLines={1}>
                      {file.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}

              <View style={styles.toolbar}>
                <Button
                  mode="text"
                  onPress={() => knowledgeBaseStore.selectAllChatFiles()}>
                  {t.all}
                </Button>
                <Button
                  mode="text"
                  onPress={() => knowledgeBaseStore.invertChatFiles()}>
                  {t.invert}
                </Button>
                <Button
                  mode="text"
                  onPress={() => knowledgeBaseStore.clearChatFiles()}>
                  {t.none}
                </Button>
              </View>
            </>
          )}

          <Button
            mode="contained"
            onPress={() => setSheetOpen(false)}
            style={{marginTop: 12}}>
            {t.done}
          </Button>
        </Modal>
      </Portal>
    </>
  );
});
