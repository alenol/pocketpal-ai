#!/usr/bin/env bash
set -e
ORPHANS=("src/screens/ModelsScreen/HFModelSearch/ModelScopeSearch.tsx")
for f in "${ORPHANS[@]}"; do
  if [ -f "$f" ]; then echo "删除孤儿文件: $f"; rm -f "$f"; else echo "无需清理(不存在): $f"; fi
done
echo "孤儿清理完成。"
