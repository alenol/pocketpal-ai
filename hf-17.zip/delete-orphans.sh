#!/usr/bin/env bash
# 清理可能残留的旧版本孤儿文件(这些文件在原版里已被删除,
# 但若解压前未清空项目目录,会残留在本地导致 Metro 打包失败)
set -e
ORPHANS=(
  "src/screens/ModelsScreen/HFModelSearch/ModelScopeSearch.tsx"
)
for f in "${ORPHANS[@]}"; do
  if [ -f "$f" ]; then
    echo "删除孤儿文件: $f"
    rm -f "$f"
  else
    echo "无需清理(不存在): $f"
  fi
done
echo "孤儿清理完成。"
