import {FIREBASE_FUNCTIONS_URL, HF_MIRROR_URL} from '@env';

// Mirror can be forced app-wide via HF_MIRROR_URL (e.g. https://hf-mirror.com).
// When set, default huggingface.co links route through the mirror so the app
// works behind the GFW without touching per-call sites.
export const HF_DOMAIN = (HF_MIRROR_URL || 'https://huggingface.co').replace(
  /\/+$/,
  '',
);
// The HF *API* (model search / metadata). In China the official
// huggingface.co is often unreachable without a proxy, while the mirror
// (hf-mirror.com) proxies the HF API too — so route the API base through
// HF_DOMAIN as well. When HF_MIRROR_URL is unset this falls back to the
// official host automatically.
export const HF_API_BASE = `${HF_DOMAIN}/api/models`;

// ---- Model download sources ------------------------------------------------
// The app can pull GGUF files from Hugging Face or its mirror (hf-mirror.com).
// Each resolves a `{repo}/resolve/{branch}/{file}` style direct link (the
// HuggingFace API shape).
export type DownloadSourceId = 'huggingface' | 'hf-mirror';

export interface DownloadSource {
  id: DownloadSourceId;
  label: string;
  branch: string;
}

export const DOWNLOAD_SOURCES: DownloadSource[] = [
  {id: 'huggingface', label: 'Hugging Face', branch: 'main'},
  {id: 'hf-mirror', label: 'HF 镜像 (hf-mirror)', branch: 'main'},
];

// In China the mirror is the safe default; users can switch per-download in the
// model search screen via the source segmented control.
export const DEFAULT_DOWNLOAD_SOURCE: DownloadSourceId = 'hf-mirror';

// Resolve a direct file URL for the given hub + `author/repo` + filename.
export const resolveFileUrl = (
  sourceId: DownloadSourceId,
  repo: string,
  filename: string,
): string => {
  const src =
    DOWNLOAD_SOURCES.find(s => s.id === sourceId) ?? DOWNLOAD_SOURCES[1];
  const branch = src.branch;
  switch (src.id) {
    case 'huggingface':
      return `https://huggingface.co/${repo}/resolve/${branch}/${filename}`;
    case 'hf-mirror':
      return `https://hf-mirror.com/${repo}/resolve/${branch}/${filename}`;
    default:
      return `https://huggingface.co/${repo}/resolve/${branch}/${filename}`;
  }
};

// Fallback for Firebase Functions URL if not configured
const FIREBASE_BASE =
  FIREBASE_FUNCTIONS_URL || 'https://placeholder-firebase-functions.com';

export const urls = {
  // API URLs
  modelsList: () => `${HF_API_BASE}`,
  modelTree: (modelId: string) => `${HF_API_BASE}/${modelId}/tree/main`,
  modelSpecs: (modelId: string) => `${HF_API_BASE}/${modelId}`,

  // Web URLs
  modelDownloadFile: (
    modelId: string,
    filename: string,
    sourceId: DownloadSourceId = DEFAULT_DOWNLOAD_SOURCE,
  ) => resolveFileUrl(sourceId, modelId, filename),
  modelWebPage: (modelId: string) => `${HF_DOMAIN}/${modelId}`,

  // Benchmark Endpoint
  benchmarkSubmit: () => `${FIREBASE_BASE}/api/v1/submit`,

  // Feedback Endpoint
  feedbackSubmit: () => `${FIREBASE_BASE}/feedback`,
};
