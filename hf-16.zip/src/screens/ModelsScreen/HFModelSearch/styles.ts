import {StyleSheet} from 'react-native';

import {Theme} from '../../../../utils/types';

export const createStyles = (theme: Theme) =>
  StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      paddingTop: 8,
    },
    title: {
      marginBottom: 4,
    },
    hint: {
      color: theme.colors.onSurfaceVariant,
      fontSize: 12,
      lineHeight: 18,
      marginBottom: 12,
    },
    input: {
      marginBottom: 10,
    },
    manualRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
      gap: 8,
    },
    manualInput: {
      flex: 1,
      borderWidth: 1,
      borderColor: theme.colors.outlineVariant,
      borderRadius: 8,
      paddingHorizontal: 12,
      paddingVertical: 8,
      color: theme.colors.onSurface,
      fontSize: 13,
    },
    list: {
      flex: 1,
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: 12,
      paddingHorizontal: 4,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.outlineVariant,
    },
    rowText: {
      flex: 1,
      marginRight: 8,
    },
    rowName: {
      fontSize: 14,
      color: theme.colors.onSurface,
    },
    rowAuthor: {
      fontSize: 12,
      color: theme.colors.onSurfaceVariant,
      marginTop: 2,
    },
    errorText: {
      color: theme.colors.error,
      fontSize: 12,
      marginBottom: 8,
    },
    empty: {
      textAlign: 'center',
      color: theme.colors.onSurfaceVariant,
      marginTop: 24,
    },
    center: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingTop: 48,
    },
  });
