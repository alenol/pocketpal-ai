import React, {useState, useContext, useEffect, useCallback} from 'react';
import {View, ActivityIndicator, FlatList, TextInput as RNTextInput} from 'react-native';
import {Text, TextInput as PaperTextInput, Button, Icon} from 'react-native-paper';
import {observer} from 'mobx-react';

import {Sheet} from '../../../../components';
import {useTheme} from '../../../../hooks';
import {L10nContext} from '../../../../utils';
import {
  MODELSCOPE_FEATURED,
  searchModelScope,
  fetchModelScopeModel,
} from '../../../../api/modelscope';
import {modelScopeAuth} from '../../../../store/modelScopeAuth';
import {createStyles} from './styles';
import {DetailsView} from './DetailsView';
import {HuggingFaceModel} from '../../../../utils/types';

interface ModelScopeSearchProps {
  visible: boolean;
  onDismiss: () => void;
}

interface ListItem {
  id: string;
  author: string;
  name: string;
}

const SEARCH_DEBOUNCE = 400;

/**
 * 「Add from 魔塔（ModelScope）」列表式浏览。
 * 仿 HFModelSearch：打开即显示模型列表 → 点模型进详情 → 可下载。
 * 魔塔无匿名搜索 API，因此默认展示内置精选清单 + 手动输入 ID；
 * 若用户在设置中填入魔塔 token，则搜索走登录 API（自由搜索）。
 */
export const ModelScopeSearch: React.FC<ModelScopeSearchProps> = observer(
  ({visible, onDismiss}) => {
    const theme = useTheme();
    const l10n = useContext(L10nContext);
    const styles = createStyles(theme);

    const [query, setQuery] = useState('');
    const [items, setItems] = useState<ListItem[]>([]);
    const [isSearching, setIsSearching] = useState(false);
    const [manualId, setManualId] = useState('');
    const [error, setError] = useState<string | null>(null);

    const [detailsVisible, setDetailsVisible] = useState(false);
    const [selectedModel, setSelectedModel] = useState<HuggingFaceModel | null>(
      null,
    );
    const [detailsLoading, setDetailsLoading] = useState(false);

    // 重置
    useEffect(() => {
      if (visible) {
        setQuery('');
        setManualId('');
        setError(null);
        // 初始展示精选清单（无 token 时即为全部；有 token 时显示热门）
        setItems(
          MODELSCOPE_FEATURED.map(id => ({
            id,
            author: id.split('/')[0],
            name: id.split('/')[1] || id,
          })),
        );
      }
    }, [visible]);

    const runSearch = useCallback(async (q: string) => {
      setIsSearching(true);
      setError(null);
      try {
        const results = await searchModelScope(q, modelScopeAuth.token);
        setItems(results);
      } catch (e: any) {
        setError(e?.message || '搜索失败');
      } finally {
        setIsSearching(false);
      }
    }, []);

    // 搜索框变化：有 token 走登录搜索，无 token 过滤精选（本地，立即）
    const handleQueryChange = useCallback(
      (text: string) => {
        setQuery(text);
        if (modelScopeAuth.isTokenPresent) {
          // 简单防抖
          const t = setTimeout(() => runSearch(text), SEARCH_DEBOUNCE);
          return () => clearTimeout(t);
        } else {
          const q = text.trim().toLowerCase();
          setItems(
            MODELSCOPE_FEATURED.filter(id => !q || id.toLowerCase().includes(q)).map(
              id => ({
                id,
                author: id.split('/')[0],
                name: id.split('/')[1] || id,
              }),
            ),
          );
        }
      },
      [runSearch],
    );

    const openModel = useCallback(
      async (repo: string) => {
        setDetailsLoading(true);
        setError(null);
        try {
          const result = await fetchModelScopeModel(repo);
          setSelectedModel(result.hfModel);
          setDetailsVisible(true);
        } catch (e: any) {
          setError(e?.message || '获取模型失败');
        } finally {
          setDetailsLoading(false);
        }
      },
      [],
    );

    const handleManualFetch = useCallback(() => {
      const id = manualId.trim().replace(/\/+$/, '');
      if (!id.includes('/')) {
        setError('模型 ID 格式应为 author/ModelName，例如 unsloth/Qwen3.5-0.8B-GGUF');
        return;
      }
      openModel(id);
    }, [manualId, openModel]);

    const renderItem = ({item}: {item: ListItem}) => (
      <View style={styles.row}>
        <View style={styles.rowText}>
          <Text style={styles.rowName}>{item.name}</Text>
          <Text style={styles.rowAuthor}>{item.author}</Text>
        </View>
        <Button
          compact
          mode="text"
          onPress={() => openModel(item.id)}>
          {l10n.models.details?.title || '详情'}
        </Button>
      </View>
    );

    return (
      <>
        <Sheet
          isVisible={visible}
          snapPoints={['92%']}
          enableDynamicSizing={false}
          enablePanDownToClose
          enableContentPanningGesture={false}
          onClose={onDismiss}
          showCloseButton={true}>
          <View style={styles.container}>
            <Text variant="titleMedium" style={styles.title}>
              从魔塔 ModelScope 添加
            </Text>
            <Text style={styles.hint}>
              魔塔无匿名搜索 API，默认展示精选 GGUF 模型；在「设置 → 魔塔 Token」
              中填入 token 后即可自由搜索。也可手动输入模型 ID。
            </Text>

            <PaperTextInput
              label="搜索 / 筛选模型"
              value={query}
              onChangeText={handleQueryChange}
              placeholder="输入关键词，如 Qwen"
              autoCapitalize="none"
              autoCorrect={false}
              style={styles.input}
              right={
                isSearching ? (
                  <PaperTextInput.Icon icon="loading" />
                ) : undefined
              }
            />

            {/* 手动输入 ID */}
            <View style={styles.manualRow}>
              <RNTextInput
                style={styles.manualInput}
                value={manualId}
                onChangeText={setManualId}
                placeholder="手动输入 author/ModelName"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Button mode="outlined" onPress={handleManualFetch} disabled={!manualId.trim()}>
                打开
              </Button>
            </View>

            {error && <Text style={styles.errorText}>{error}</Text>}

            <FlatList
              data={items}
              keyExtractor={item => item.id}
              renderItem={renderItem}
              style={styles.list}
              ListEmptyComponent={
                !isSearching ? (
                  <Text style={styles.empty}>没有匹配的模型</Text>
                ) : null
              }
            />
          </View>
        </Sheet>

        <Sheet
          isVisible={detailsVisible}
          snapPoints={['90%']}
          enableDynamicSizing={false}
          enablePanDownToClose
          enableContentPanningGesture={false}
          onClose={() => setDetailsVisible(false)}
          showCloseButton={false}>
          {detailsLoading ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" />
            </View>
          ) : (
            selectedModel && (
              <DetailsView hfModel={selectedModel} defaultSource="modelscope" />
            )
          )}
        </Sheet>
      </>
    );
  },
);
