/**
 * Built-in model fingerprints used to auto-configure locally imported GGUF
 * files. When a user imports a bare `.gguf` (not downloaded through the in-app
 * preset catalog), the app has no metadata about it — so multimodal/auxiliary
 * models are not matched the way they are for catalog models. This table lets
 * `ModelStore.matchLocalModelPreset` recover that metadata from the filename
 * (and, for vision models, from a companion mmproj already on device).
 *
 * Matching is fuzzy on purpose: imported files often use a different
 * quantization than the catalog entry, so we match the model *family* (e.g.
 * "SmolVLM-500M") rather than the full filename.
 */

export interface ModelFingerprint {
  /** Matches the imported GGUF filename (case-insensitive). */
  family: RegExp;
  isVision: boolean;
  capabilities: string[];
  /** Companion mmproj filename pattern (case-insensitive), same family. */
  mmprojPattern?: RegExp;
  /**
   * chatTemplate key in `chat.ts` to auto-apply when known and safe. Left
   * undefined for families whose template we do not hard-code, so we keep the
   * model's default template instead of guessing wrong.
   */
  chatTemplateKey?: string;
}

export const MODEL_FINGERPRINTS: ModelFingerprint[] = [
  // ---- Vision / multimodal LLMs -------------------------------------------
  {
    family: /smolvlm/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj.*smolvlm/i,
    chatTemplateKey: 'smolVLM',
  },
  {
    family: /qwen2?-?vl/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /llama-3\.?2-vision/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /minicpm-v/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /phi-3\.?5-vision/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /gemma-3/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /molmo/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /internvl/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
  {
    family: /paligemma/i,
    isVision: true,
    capabilities: ['vision'],
    mmprojPattern: /mmproj/i,
  },
];

/**
 * Find the fingerprint that matches an imported filename, if any.
 */
export function matchFingerprint(filename: string): ModelFingerprint | undefined {
  return MODEL_FINGERPRINTS.find(fp => fp.family.test(filename));
}
