/**
 * 调试日志捕获工具（用于 npubuild-debug 版本）。
 *
 * 在 App 启动时调用 `installLogger()`，即可把全局 `console.*` 输出以及
 * `window.onerror` / `unhandledrejection` 异常写入一个内存环形缓冲区，
 * 用户可在「设置 → 调试」里一键复制最近日志，便于在真机上排查下载 / NPU 等问题。
 *
 * 注意：该模块在 release 构建中也会被打包，但只在调用 installLogger()
 * 后才开始记录，不会对性能产生明显影响；如需彻底关闭，注释掉 App.tsx 中的
 * 安装调用即可。
 */

const MAX_LINES = 2000;

type LogLevel = 'log' | 'info' | 'warn' | 'error' | 'debug';

interface LogEntry {
  t: string; // 时间戳 ISO
  level: LogLevel;
  msg: string;
}

const buffer: LogEntry[] = [];

function push(level: LogLevel, args: unknown[]): void {
  const ts = new Date().toISOString();
  let msg = '';
  try {
    msg = args
      .map(a => {
        if (typeof a === 'string') return a;
        if (a instanceof Error) return `${a.name}: ${a.message}\n${a.stack || ''}`;
        try {
          return JSON.stringify(a);
        } catch {
          return String(a);
        }
      })
      .join(' ');
  } catch {
    msg = '[unable to serialize log args]';
  }
  buffer.push({t: ts, level, msg});
  if (buffer.length > MAX_LINES) {
    buffer.splice(0, buffer.length - MAX_LINES);
  }
}

function serializeError(e: unknown): string {
  if (e instanceof Error) return `${e.name}: ${e.message}\n${e.stack || ''}`;
  return String(e);
}

let installed = false;

/**
 * 安装全局日志捕获。幂等（多次调用安全）。
 * 必须在 React Native 运行环境内调用（需要 console）。
 */
export function installLogger(): void {
  if (installed) return;
  installed = true;

  const original = {
    log: console.log,
    info: console.info,
    warn: console.warn,
    error: console.error,
    debug: console.debug,
  };

  console.log = (...args: unknown[]) => {
    push('log', args);
    original.log.apply(console, args as []);
  };
  console.info = (...args: unknown[]) => {
    push('info', args);
    original.info.apply(console, args as []);
  };
  console.warn = (...args: unknown[]) => {
    push('warn', args);
    original.warn.apply(console, args as []);
  };
  console.error = (...args: unknown[]) => {
    push('error', args);
    original.error.apply(console, args as []);
  };
  console.debug = (...args: unknown[]) => {
    push('debug', args);
    original.debug.apply(console, args as []);
  };

  // 捕获未处理的 JS 异常与 Promise rejection
  if (typeof global !== 'undefined') {
    const g = global as unknown as {
      ErrorUtils?: {getGlobalHandler?: () => unknown; setGlobalHandler?: (h: unknown) => void};
      addEventListener?: (type: string, cb: (e: unknown) => void) => void;
    };
    if (g.ErrorUtils && typeof g.ErrorUtils.setGlobalHandler === 'function') {
      const prev = g.ErrorUtils.getGlobalHandler?.();
      g.ErrorUtils.setGlobalHandler((err: unknown, isFatal?: boolean) => {
        push('error', [`[global-error${isFatal ? ' FATAL' : ''}]`, serializeError(err)]);
        // @ts-expect-error 调用原始 handler
        if (typeof prev === 'function') prev(err, isFatal);
      });
    }
    if (typeof g.addEventListener === 'function') {
      g.addEventListener('unhandledrejection', (e: unknown) => {
        const reason = (e as {reason?: unknown})?.reason;
        push('error', ['[unhandledrejection]', serializeError(reason)]);
      });
    }
  }
}

/** 返回全部日志文本（纯文本，按时间排序，带级别标记）。 */
export function getLogText(): string {
  return buffer
    .map(e => `[${e.t}] ${e.level.toUpperCase()}: ${e.msg}`)
    .join('\n');
}

/** 返回当前缓冲行数。 */
export function getLogCount(): number {
  return buffer.length;
}

/** 清空缓冲（用于"复制后清空"或测试）。 */
export function clearLogs(): void {
  buffer.length = 0;
}
