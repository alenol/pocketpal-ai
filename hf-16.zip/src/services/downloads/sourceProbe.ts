/**
 * 下载源可用性探测（sourceProbe）。
 *
 * 当前支持的可直链下载源（均经沙箱实测）：
 *   - Hugging Face / HF 镜像：标准 /resolve/{branch}/{file}，已验证可用。
 *   - ModelScope 魔塔：有公开文件列表 API，可精确判断「模型/文件是否存在」
 *     并返回文件大小，下载走 /repo?Revision=&FilePath= 端点（匿名可用）。
 *
 * 已放弃的源（按用户授权，App 内无法免登录直链）：
 *   - Modelers 魔乐：站点未开放公开模型接口（全 404 / 错误页）。
 *   - AtomGit / GitCode AI：文件下载接口被 CloudWAF 拦截（HTTP 418），仅网页
 *     登录态可下，App 内匿名直链在架构上不可行。
 *
 * 该模块用途：用户选择某个下载源、点击下载前，先探测该源能否真正提供这个
 * 文件；能下就返回「可下载 + 地址 + 大小」，不能下就给出明确原因，避免发起
 * 注定失败的下载。
 */

import {DownloadSourceId} from '../../config/urls';

export interface SourceProbeResult {
  /** 该源是否能让 App 直接下载此文件 */
  available: boolean;
  /** 校验过的真实下载地址（available 为 true 时存在） */
  url?: string;
  /** 文件字节数（已知时） */
  sizeBytes?: number;
  /** 给用户看的状态说明（中文） */
  message: string;
}

const MS_FILES_API = (repo: string, branch: string) =>
  `https://modelscope.cn/api/v1/models/${repo}/repo/files?Revision=${branch}&Recursive=true`;

const MS_DOWNLOAD = (repo: string, branch: string, file: string) =>
  `https://modelscope.cn/api/v1/models/${repo}/repo?Revision=${branch}&FilePath=${file}`;

interface MsFileEntry {
  Name?: string;
  Path?: string;
  Size?: number;
}

/**
 * 探测某个下载源是否能为 (repo, branch, filename) 提供可下载文件。
 * @param sourceId 下载源 id
 * @param repo     形如 `author/ModelName`
 * @param branch   分支（main / master）
 * @param filename 文件名（如 xxx-Q3_K_M.gguf）
 */
export async function probeSource(
  sourceId: DownloadSourceId,
  repo: string,
  branch: string,
  filename: string,
): Promise<SourceProbeResult> {
  switch (sourceId) {
    case 'huggingface':
    case 'hf-mirror': {
      // 用户已确认这两类源可用，跳过网络探测以减少延迟。
      const host =
        sourceId === 'hf-mirror' ? 'hf-mirror.com' : 'huggingface.co';
      return {
        available: true,
        url: `https://${host}/${repo}/resolve/${branch}/${filename}`,
        message: '可直接下载',
      };
    }

    case 'modelscope': {
      try {
        const res = await fetch(MS_FILES_API(repo, branch));
        if (!res.ok) {
          return {
            available: false,
            message: `魔塔上未找到该模型（接口返回 HTTP ${res.status}）`,
          };
        }
        const json = (await res.json()) as {
          Code?: number;
          Data?: {Files?: MsFileEntry[]};
        };
        const files: MsFileEntry[] = json?.Data?.Files ?? [];
        if (!files.length) {
          return {available: false, message: '魔塔上未找到该模型'};
        }
        const hit = files.find(
          f =>
            f.Name === filename ||
            f.Path === filename ||
            f.Path?.endsWith(`/${filename}`),
        );
        if (!hit) {
          return {
            available: false,
            message: `该文件在魔塔上不存在（该模型共 ${files.length} 个文件）`,
          };
        }
        return {
          available: true,
          url: MS_DOWNLOAD(repo, branch, filename),
          sizeBytes: typeof hit.Size === 'number' ? hit.Size : undefined,
          message: '可直接下载',
        };
      } catch {
        return {available: false, message: '魔塔接口请求失败，请检查网络'};
      }
    }

    default:
      // 未知源：保守放行（理论上不会发生，因为下载源列表已收敛）。
      return {
        available: true,
        url: `https://huggingface.co/${repo}/resolve/${branch}/${filename}`,
        message: '可直接下载',
      };
  }
}
