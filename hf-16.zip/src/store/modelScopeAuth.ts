/**
 * 魔塔（ModelScope）登录态凭证存储。
 *
 * 魔塔的「模型列表/搜索」接口需要登录（匿名返回 user not logged in），而单个
 * 模型的详情/文件列表可匿名访问。为支持「像 Hugging Face 那样自由搜索魔塔」，
 * 这里把用户可选项填的魔塔 token 存到系统密钥库；有 token 时搜索走登录 API，
 * 无 token 时退回「内置精选清单 + 手动输入模型 ID」。
 */

import * as Keychain from 'react-native-keychain';
import {makeAutoObservable, runInAction} from 'mobx';

const MS_TOKEN_SERVICE = 'modelscope_token_service';

class ModelScopeAuth {
  token: string | null = null;

  constructor() {
    makeAutoObservable(this);
    this.loadFromSecureStorage();
  }

  private async loadFromSecureStorage() {
    try {
      const creds = await Keychain.getGenericPassword({
        service: MS_TOKEN_SERVICE,
      });
      if (creds) {
        runInAction(() => {
          this.token = creds.password;
        });
      }
    } catch (e) {
      console.error('Failed to load ModelScope token:', e);
    }
  }

  get isTokenPresent(): boolean {
    return !!this.token && this.token.trim().length > 0;
  }

  async setToken(token: string) {
    const trimmed = token.trim();
    try {
      if (trimmed) {
        await Keychain.setGenericPassword('modelscope_token', trimmed, {
          service: MS_TOKEN_SERVICE,
        });
      } else {
        await Keychain.resetGenericPassword({service: MS_TOKEN_SERVICE});
      }
      runInAction(() => {
        this.token = trimmed || null;
      });
      return true;
    } catch (e) {
      console.error('Failed to save ModelScope token:', e);
      return false;
    }
  }

  async clearToken() {
    try {
      await Keychain.resetGenericPassword({service: MS_TOKEN_SERVICE});
      runInAction(() => {
        this.token = null;
      });
      return true;
    } catch (e) {
      console.error('Failed to clear ModelScope token:', e);
      return false;
    }
  }
}

export const modelScopeAuth = new ModelScopeAuth();
