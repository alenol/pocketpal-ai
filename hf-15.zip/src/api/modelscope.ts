/**
 * ModelScope（魔塔）模型获取。
 *
 * 与 Hugging Face 不同，魔塔的「模型列表/搜索」接口需要登录（POST 返回
 * user not logged in），只有「已知模型 ID 的详情」和「文件列表」可匿名访问。
 * 因此本模块支持的是「Add from 魔塔：按模型 ID 导入」——用户输入形如
 * `unsloth/Qwen3.5-0.8B-GGUF` 的模型 ID，我们匿名拉取详情与文件列表。
 *
 * 文件下载走魔塔的 /repo?Revision=&FilePath= 端点（匿名可用，已实测）。
 */

import {resolveFileUrl} from '../config/urls';
import {HuggingFaceModel, ModelFile} from '../utils/types';

const MS_DETAIL_API = (repo: string) =>
  `https://modelscope.cn/api/v1/models/${repo}`;
const MS_FILES_API = (repo: string, branch: string) =>
  `https://modelscope.cn/api/v1/models/${repo}/repo/files?Revision=${branch}&Recursive=true`;

const MS_BRANCH = 'master';

interface MsDetailResponse {
  Code?: number;
  Message?: string;
  Data?: {
    Id?: string;
    Downloads?: number;
    Author?: string;
    License?: string;
    Tags?: string[];
    CreatedAt?: string;
    UpdatedAt?: string;
  };
}

interface MsFileEntry {
  Name?: string;
  Path?: string;
  Size?: number;
  Type?: string;
}

export interface ModelScopeModel {
  /** 兼容 pocketpal 的 HuggingFaceModel（仅填充运行时用到的字段） */
  hfModel: HuggingFaceModel;
  /** 该仓库下的全部 .gguf 文件（含 mmproj），已带 size 与魔塔直链 url */
  ggufFiles: ModelFile[];
}

function isGguf(name?: string): boolean {
  return !!name && name.toLowerCase().endsWith('.gguf');
}

/**
 * 按模型 ID 拉取魔塔模型详情与文件列表。
 * @param repo 形如 `author/ModelName`
 */
export async function fetchModelScopeModel(repo: string): Promise<ModelScopeModel> {
  const cleanRepo = repo.trim().replace(/\/+$/, '');
  if (!cleanRepo.includes('/')) {
    throw new Error('模型 ID 格式应为 author/ModelName，例如 unsloth/Qwen3.5-0.8B-GGUF');
  }

  // 1) 文件列表（含大小，匿名可用）
  const filesRes = await fetch(MS_FILES_API(cleanRepo, MS_BRANCH));
  if (!filesRes.ok) {
    if (filesRes.status === 404) {
      throw new Error(`魔塔上未找到模型「${cleanRepo}」`);
    }
    throw new Error(`魔塔文件列表接口返回 HTTP ${filesRes.status}`);
  }
  const filesJson = (await filesRes.json()) as {
    Code?: number;
    Data?: {Files?: MsFileEntry[]};
  };
  const entries: MsFileEntry[] = filesJson?.Data?.Files ?? [];
  if (!entries.length) {
    throw new Error(`魔塔上未找到模型「${cleanRepo}」`);
  }

  const ggufFiles: ModelFile[] = entries
    .filter(e => isGguf(e.Name) || isGguf(e.Path))
    .map(e => {
      const name = e.Name || e.Path || '';
      return {
        rfilename: name,
        size: typeof e.Size === 'number' ? e.Size : undefined,
        url: resolveFileUrl('modelscope', cleanRepo, name),
      } as ModelFile;
    });

  if (!ggufFiles.length) {
    throw new Error(`模型「${cleanRepo}」在魔塔上不包含任何 .gguf 文件`);
  }

  // 2) 模型详情（可选；失败不影响导入，仅用于补全元信息）
  let author = cleanRepo.split('/')[0];
  let downloads = 0;
  try {
    const detailRes = await fetch(MS_DETAIL_API(cleanRepo));
    if (detailRes.ok) {
      const d = (await detailRes.json()) as MsDetailResponse;
      author = d.Data?.Author || author;
      downloads = d.Data?.Downloads || 0;
    }
  } catch {
    // 忽略详情错误
  }

  // hfAsModel 运行时只用到 id / siblings / author / specs / url，其余字段用
  // 占位值并经类型断言兜底（避免与 HuggingFaceModel 严格结构逐一对齐）。
  const hfModel = {
    _id: cleanRepo,
    id: cleanRepo,
    author,
    gated: false,
    inference: '',
    lastModified: '',
    likes: 0,
    trendingScore: 0,
    private: false,
    sha: '',
    downloads,
    tags: [],
    library_name: '',
    createdAt: '',
    model_id: cleanRepo,
    siblings: ggufFiles,
    url: `https://modelscope.cn/models/${cleanRepo}`,
  } as unknown as HuggingFaceModel;

  return {hfModel, ggufFiles};
}
