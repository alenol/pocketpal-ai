import {StyleSheet} from 'react-native';
import {Theme} from '../../utils/types';

export const createStyles = (theme: Theme) => {
  return StyleSheet.create({
    container: {
      padding: 16,
      paddingBottom: 32,
    },
    hint: {
      color: theme.colors.onSurfaceVariant,
      fontSize: 13,
      marginBottom: 12,
      lineHeight: 19,
    },
    inputSpacing: {
      marginBottom: 12,
    },
    statusRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 8,
    },
    statusText: {
      marginLeft: 8,
      color: theme.colors.onSurfaceVariant,
      fontSize: 13,
    },
    errorBox: {
      backgroundColor: theme.colors.errorContainer,
      padding: 12,
      borderRadius: 8,
      marginBottom: 8,
    },
    errorText: {
      color: theme.colors.onErrorContainer,
      fontSize: 13,
    },
    fileListSection: {
      marginTop: 8,
    },
    fileListLabel: {
      fontSize: 14,
      fontWeight: '600',
      marginBottom: 8,
      color: theme.colors.onSurface,
    },
    fileRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: 8,
      paddingHorizontal: 4,
      borderBottomWidth: 1,
      borderBottomColor: theme.colors.outlineVariant,
    },
    fileRowText: {
      flex: 1,
      marginRight: 8,
    },
    fileName: {
      fontSize: 13,
      color: theme.colors.onSurface,
    },
    fileSize: {
      fontSize: 12,
      color: theme.colors.onSurfaceVariant,
      marginTop: 2,
    },
  });
};
