import React, {useState, useContext, useEffect, useCallback} from 'react';
import {View, ActivityIndicator, TouchableOpacity} from 'react-native';
import {Text, Button, TextInput as PaperTextInput} from 'react-native-paper';
import {observer} from 'mobx-react';
import {Sheet, TextInput} from '..';
import {useTheme} from '../../hooks';
import {L10nContext} from '../../utils';
import {fetchModelScopeModel} from '../../api/modelscope';
import {modelStore} from '../../store';
import {ModelFile} from '../../utils/types';
import {formatBytes} from '../../utils';
import {createStyles} from './styles';

interface ModelScopeSheetProps {
  isVisible: boolean;
  onDismiss: () => void;
  onModelAdded?: () => void;
}

/**
 * 「Add from ModelScope（魔塔）」：按模型 ID 导入。
 * 魔塔的搜索列表接口需要登录，但已知模型 ID 的详情与文件列表可匿名访问，
 * 因此这里走「输入 author/ModelName → 拉取 .gguf 文件列表 → 直接下载」的流程，
 * 完全免登录，且文件下载走魔塔直链（/repo? 端点）。
 */
export const ModelScopeSheet: React.FC<ModelScopeSheetProps> = observer(
  ({isVisible, onDismiss, onModelAdded}) => {
    const theme = useTheme();
    const l10n = useContext(L10nContext);
    const styles = createStyles(theme);

    const [repo, setRepo] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [ggufFiles, setGgufFiles] = useState<ModelFile[]>([]);
    const [hfModel, setHfModel] = useState<any>(null);
    const [downloadingName, setDownloadingName] = useState<string | null>(null);

    // 重置状态
    useEffect(() => {
      if (isVisible) {
        setRepo('');
        setIsLoading(false);
        setError(null);
        setGgufFiles([]);
        setHfModel(null);
        setDownloadingName(null);
      }
    }, [isVisible]);

    const handleFetch = useCallback(async () => {
      const id = repo.trim().replace(/\/+$/, '');
      if (!id) {
        setError('请输入魔塔模型 ID，例如 unsloth/Qwen3.5-0.8B-GGUF');
        return;
      }
      setIsLoading(true);
      setError(null);
      setGgufFiles([]);
      setHfModel(null);
      try {
        const result = await fetchModelScopeModel(id);
        setHfModel(result.hfModel);
        setGgufFiles(result.ggufFiles);
        if (result.ggufFiles.length === 0) {
          setError('该模型在魔塔上不包含任何 .gguf 文件');
        }
      } catch (e: any) {
        setError(e?.message || '拉取魔塔模型失败，请检查模型 ID 或网络');
      } finally {
        setIsLoading(false);
      }
    }, [repo]);

    const handleDownload = useCallback(
      async (file: ModelFile) => {
        if (!hfModel || !file.url) {
          return;
        }
        setDownloadingName(file.rfilename);
        try {
          // 复用与「Add from Hugging Face」完全相同的下载入口；
          // modelFile.url 已是魔塔直链，downloadHFModel 不会反查 HF。
          await modelStore.downloadHFModel(hfModel, file, {
            enableVision: true,
          });
          onModelAdded?.();
          onDismiss();
        } catch (e: any) {
          setError(e?.message || '开始下载失败');
        } finally {
          setDownloadingName(null);
        }
      },
      [hfModel, onModelAdded, onDismiss],
    );

    return (
      <Sheet
        isVisible={isVisible}
        onClose={onDismiss}
        title="从魔塔 ModelScope 添加"
        snapPoints={['85%']}>
        <Sheet.ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.hint}>
            输入魔塔模型 ID（author/ModelName）即可免登录导入并下载，例如
            unsloth/Qwen3.5-0.8B-GGUF。魔塔不支持免登录搜索，因此按模型 ID
            导入；文件从魔塔直链下载。
          </Text>

          <View style={styles.inputSpacing}>
            <TextInput
              testID="modelscope-id-input"
              label="魔塔模型 ID"
              value={repo}
              onChangeText={text => {
                setRepo(text);
                if (error) setError(null);
              }}
              placeholder="unsloth/Qwen3.5-0.8B-GGUF"
              autoCapitalize="none"
              autoCorrect={false}
              spellCheck={false}
            />
          </View>

          <View style={styles.inputSpacing}>
            <Button
              mode="contained"
              onPress={handleFetch}
              loading={isLoading}
              disabled={isLoading || !repo.trim()}>
              获取文件列表
            </Button>
          </View>

          {isLoading && (
            <View style={styles.statusRow}>
              <ActivityIndicator size="small" />
              <Text style={styles.statusText}>正在从魔塔拉取…</Text>
            </View>
          )}

          {error && !isLoading && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          {!isLoading && ggufFiles.length > 0 && (
            <View style={styles.fileListSection}>
              <Text style={styles.fileListLabel}>
                可下载的 .gguf 文件（共 {ggufFiles.length} 个）
              </Text>
              {ggufFiles.map(file => {
                const sizeText =
                  file.size != null
                    ? ` · ${formatBytes(file.size)}`
                    : '';
                const isDownloading =
                  downloadingName === file.rfilename;
                return (
                  <TouchableOpacity
                    key={file.rfilename}
                    activeOpacity={0.6}
                    style={styles.fileRow}
                    disabled={isDownloading}
                    onPress={() => handleDownload(file)}>
                    <View style={styles.fileRowText}>
                      <Text style={styles.fileName}>{file.rfilename}</Text>
                      <Text style={styles.fileSize}>{sizeText}</Text>
                    </View>
                    <Button
                      compact
                      mode="text"
                      loading={isDownloading}
                      disabled={isDownloading}>
                      下载
                    </Button>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </Sheet.ScrollView>
      </Sheet>
    );
  },
);
